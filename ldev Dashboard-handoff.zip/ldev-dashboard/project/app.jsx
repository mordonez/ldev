/* ldev dashboard — App root */
const { useState: useStateA, useEffect: useEffectA, useMemo, useRef: useRefA } = React;
const useState = useStateA, useEffect = useEffectA, useRef = useRefA;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "density": "comfortable",
  "accent": "#4FAEE0"
}/*EDITMODE-END*/;

let TASK_SEQ = 1;

function App() {
  const L = window.LDEV;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const [filter, setFilter] = useState('all');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState('priority');
  const [selected, setSelected] = useState(null);
  const [logsFor, setLogsFor] = useState(null);
  const [showNew, setShowNew] = useState(false);
  const [runtime, setRuntime] = useState({});      // name -> 'starting'|'running'|'stopping'|'stopped'
  const [tasks, setTasks] = useState([]);
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [toast, setToast] = useState(null);
  const [copied, setCopied] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [now, setNow] = useState(new Date());

  // apply theme tweaks to <html>
  useEffect(() => {
    const r = document.documentElement;
    r.setAttribute('data-theme', t.theme);
    r.setAttribute('data-density', t.density);
    r.style.setProperty('--accent', t.accent);
  }, [t.theme, t.density, t.accent]);

  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(null), 2400); };
  const copy = (text) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopied(text);
    setTimeout(() => setCopied((c) => (c === text ? null : c)), 1600);
  };

  // runtime state resolver
  const rt = (wt) => {
    const o = runtime[wt.name];
    if (o) return o;
    return L.isRunning(wt) ? 'running' : 'stopped';
  };

  const addTask = (title, sub) => {
    const id = TASK_SEQ++;
    setTasks((ts) => [{ id, title, sub, status: 'running', progress: 8 }, ...ts].slice(0, 8));
    setDockCollapsed(false);
    return id;
  };
  const tickTask = (id, progress) => setTasks((ts) => ts.map((x) => (x.id === id ? { ...x, progress } : x)));
  const finishTask = (id, status) => setTasks((ts) => ts.map((x) => (x.id === id ? { ...x, status, progress: 100 } : x)));

  const startEnv = (name) => {
    setRuntime((r) => ({ ...r, [name]: 'starting' }));
    const id = addTask(`Start env · ${name}`, 'docker compose up -d');
    let p = 8;
    const iv = setInterval(() => { p = Math.min(92, p + 14); tickTask(id, p); }, 450);
    setTimeout(() => {
      clearInterval(iv);
      setRuntime((r) => ({ ...r, [name]: 'running' }));
      finishTask(id, 'done');
      showToast(`${name} is up`);
    }, 2600);
  };
  const stopEnv = (name) => {
    setRuntime((r) => ({ ...r, [name]: 'stopping' }));
    const id = addTask(`Stop env · ${name}`, 'docker compose down');
    setTimeout(() => {
      setRuntime((r) => ({ ...r, [name]: 'stopped' }));
      finishTask(id, 'done');
      showToast(`${name} stopped`);
    }, 1500);
  };
  const runAction = (kind, name) => {
    const labels = {
      db: ['DB sync', 'ldev db sync'], resource: ['Resource export', 'ldev resource export-*'],
      oauth: ['OAuth install', 'ldev oauth install'], deploy: ['Deploy status', 'ldev deploy status'],
      recreate: ['Recreate env', 'ldev worktree recreate'], delete: ['Delete worktree', 'ldev worktree remove'],
      diagnose: ['Diagnose repo', 'ldev doctor'],
    };
    const [title, sub] = labels[kind] || [kind, ''];
    const id = addTask(`${title}${name ? ' · ' + name : ''}`, sub);
    let p = 10;
    const iv = setInterval(() => { p = Math.min(90, p + 18); tickTask(id, p); }, 500);
    setTimeout(() => { clearInterval(iv); finishTask(id, kind === 'deploy' ? 'failed' : 'done'); }, 2200);
    showToast(`Queued: ${title}`);
  };

  const doRefresh = () => { setRefreshing(true); setTimeout(() => setRefreshing(false), 700); };

  // ── derived ──
  const enriched = useMemo(() => L.worktrees.map((wt) => ({ wt, run: rt(wt) })), [runtime]);

  const stats = useMemo(() => {
    const s = { total: L.worktrees.length, running: 0, attention: 0, attentionOnly: 0, error: 0, dirty: 0, up: 0, idle: 0, withEnv: 0 };
    for (const wt of L.worktrees) {
      const run = rt(wt);
      const running = run === 'running';
      if (wt.env) s.withEnv++;
      if (running) {
        s.running++;
        if (wt.env?.portalReachable !== false) s.up++;
        if (L.failedServices(wt).length || wt.env?.portalReachable === false) s.error++;
      }
      if (L.needsAttention(wt)) s.attention++;
      if (L.isDirty(wt)) s.dirty++;
      if (!running && !L.needsAttention(wt) && !wt.isMain) s.idle++;
      if (L.needsAttention(wt) && !running) s.attentionOnly++;
    }
    return s;
  }, [runtime]);

  const matchFilter = (wt, run) => {
    if (filter === 'attention') return L.needsAttention(wt);
    if (filter === 'running') return run === 'running';
    if (filter === 'dirty') return L.isDirty(wt);
    if (filter === 'up') return run === 'running' && wt.env?.portalReachable !== false;
    if (filter === 'main') return wt.isMain;
    return true;
  };
  const matchQuery = (wt) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return [wt.name, wt.branch, wt.path].join(' ').toLowerCase().includes(q);
  };

  const counts = useMemo(() => {
    const c = {};
    for (const [key] of FILTERS) c[key] = enriched.filter(({ wt, run }) => {
      if (key === 'all') return true;
      if (key === 'attention') return L.needsAttention(wt);
      if (key === 'running') return run === 'running';
      if (key === 'dirty') return L.isDirty(wt);
      if (key === 'main') return wt.isMain;
      return true;
    }).length;
    return c;
  }, [enriched]);

  const visible = useMemo(() => {
    let list = enriched.filter(({ wt, run }) => matchFilter(wt, run) && matchQuery(wt));
    list = list.slice().sort((a, b) => {
      if (sort === 'name') return a.wt.name.localeCompare(b.wt.name);
      if (sort === 'changes') return (b.wt.changedFiles || 0) - (a.wt.changedFiles || 0);
      return L.priority(a.wt) - L.priority(b.wt) || a.wt.name.localeCompare(b.wt.name);
    });
    return list;
  }, [enriched, filter, query, sort]);

  const selectedWt = selected ? L.worktrees.find((w) => w.name === selected) : null;
  const logsWt = logsFor ? L.worktrees.find((w) => w.name === logsFor) : null;
  const updatedAt = `updated ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`;

  return (
    <div className="app">
      <Header cwd={L.cwd} query={query} onQuery={setQuery} onNew={() => setShowNew(true)}
        onDiagnose={() => runAction('diagnose', null)} onRefresh={doRefresh} refreshing={refreshing} updatedAt={updatedAt}
        theme={t.theme} onToggleTheme={() => setTweak('theme', t.theme === 'dark' ? 'light' : 'dark')} />

      <div className="body">
        <Overview stats={stats} activeFilter={filter} onFilter={(f) => setFilter((cur) => (cur === f ? 'all' : f))} />
        <Toolbar activeFilter={filter} counts={counts} onFilter={setFilter}
          total={L.worktrees.length} visible={visible.length} sort={sort} onSort={setSort} />

        {visible.length ? (
          <div className="grid">
            {visible.map(({ wt, run }) => (
              <WorktreeCard key={wt.name} wt={wt} runtime={runtime[wt.name] || null}
                selected={selected === wt.name} onSelect={setSelected}
                onStart={startEnv} onStop={stopEnv} onLogs={setLogsFor}
                onCopy={copy} copied={copied} />
            ))}
          </div>
        ) : (
          <div className="empty">No worktrees match “{query || filter}”.</div>
        )}

        <ActivityDock tasks={tasks} collapsed={dockCollapsed} onToggle={() => setDockCollapsed((c) => !c)} />
      </div>

      {selectedWt && (
        <DetailSheet wt={selectedWt} runtime={runtime[selectedWt.name] || null} onClose={() => setSelected(null)}
          onStart={startEnv} onStop={stopEnv} onLogs={setLogsFor} onAction={runAction} onCopy={copy} copied={copied} />
      )}
      {logsWt && <LogsModal wt={logsWt} onClose={() => setLogsFor(null)} />}
      {showNew && <NewWorktreeModal onClose={() => setShowNew(false)}
        onCreate={(form) => { setShowNew(false); showToast(`Queued: create ${form.name}`); runAction('recreate', form.name); }} />}

      <div className={cx('toast', toast && 'show')}>{toast ? <React.Fragment><span className="tdot"></span>{toast}</React.Fragment> : null}</div>

      <TweaksPanel>
        <TweakSection label="Appearance" />
        <TweakRadio label="Theme" value={t.theme} options={['dark', 'light']} onChange={(v) => setTweak('theme', v)} />
        <TweakRadio label="Density" value={t.density} options={['comfortable', 'compact']} onChange={(v) => setTweak('density', v)} />
        <TweakColor label="Accent" value={t.accent}
          options={['#4FAEE0', '#34D399', '#A78BFA', '#F5934F']} onChange={(v) => setTweak('accent', v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
