/* ldev dashboard — header, overview, toolbar, worktree card */
const { useState, useRef, useEffect } = React;
const cx = (...a) => a.filter(Boolean).join(' ');

/* ── Header ──────────────────────────────────────────────── */
function Header({ cwd, query, onQuery, onNew, onDiagnose, onRefresh, refreshing, updatedAt, theme, onToggleTheme }) {
  return (
    <header className="hdr">
      <div className="brand">
        <div className="brand-mark">l</div>
        <div className="brand-name">ldev</div>
      </div>
      <div className="repo-chip" title={cwd}>
        <I.Folder size={14} />
        <span className="path">{cwd}</span>
      </div>
      <div className="hdr-spacer"></div>
      <div className="hdr-search">
        <I.Search size={15} />
        <input value={query} placeholder="Search worktrees…" onInput={(e) => onQuery(e.target.value)} />
      </div>
      <div className="refresh" title="Auto-refreshing">
        <span className="live"></span>
        <span>{updatedAt}</span>
      </div>
      <button className={cx('icon-btn', refreshing && 'spin')} title="Refresh now" onClick={onRefresh}>
        <I.Refresh size={15} />
      </button>
      <button className="icon-btn" title={theme === 'dark' ? 'Switch to light' : 'Switch to dark'} onClick={onToggleTheme}>
        {theme === 'dark' ? <I.Sun size={15} /> : <I.Moon size={15} />}
      </button>
      <button className="btn btn-ghost" onClick={onDiagnose}><I.Stethoscope size={15} />Diagnose</button>
      <button className="btn btn-primary" onClick={onNew}><I.Plus size={15} />New worktree</button>
    </header>
  );
}

/* ── Overview KPI bar ────────────────────────────────────── */
function Overview({ stats, activeFilter, onFilter }) {
  const total = stats.total;
  const seg = (n, cls) => (total ? `${(n / total) * 100}%` : '0%');
  return (
    <div className="overview">
      <div className="kpi kpi-hero">
        <div className="kpi-top">
          <span className="kpi-label">Worktrees</span>
          <I.Box size={15} style={{ color: 'var(--text-3)' }} />
        </div>
        <div className="kpi-row">
          <span className="kpi-num">{total}</span>
          <span className="kpi-sub">{stats.withEnv} with a local env</span>
        </div>
        <div className="kpi-bars">
          <i className="bg-green" style={{ flex: stats.running || 0.001 }}></i>
          <i className="bg-amber" style={{ flex: stats.attentionOnly || 0.001 }}></i>
          <i className="bg-red" style={{ flex: stats.error || 0.001 }}></i>
          <i className="bg-gray" style={{ flex: stats.idle || 0.001 }}></i>
        </div>
      </div>
      <KpiTile label="Running" num={stats.running} dot="green" sub="live portals"
        active={activeFilter === 'running'} onClick={() => onFilter('running')} />
      <KpiTile label="Need attention" num={stats.attention} dot="amber" sub="dirty / behind / unhealthy"
        active={activeFilter === 'attention'} onClick={() => onFilter('attention')} />
      <KpiTile label="Uncommitted" num={stats.dirty} dot="gray" sub="worktrees with changes"
        active={activeFilter === 'dirty'} onClick={() => onFilter('dirty')} />
      <KpiTile label="Ports up" num={stats.up} dot="accent" sub="reachable endpoints"
        active={activeFilter === 'up'} onClick={() => onFilter('up')} />
    </div>
  );
}
function KpiTile({ label, num, dot, sub, active, onClick }) {
  return (
    <div className={cx('kpi', 'is-link', active && 'is-active')} onClick={onClick}>
      <div className="kpi-top">
        <span className="kpi-label">{label}</span>
        <span className={cx('kpi-dot', `dot-${dot}`)}></span>
      </div>
      <div className="kpi-row"><span className="kpi-num">{num}</span></div>
      <span className="kpi-sub">{sub}</span>
    </div>
  );
}

/* ── Toolbar / filters ───────────────────────────────────── */
const FILTERS = [
  ['all', 'All'], ['attention', 'Attention'], ['running', 'Running'],
  ['dirty', 'Dirty'], ['main', 'Main'],
];
function Toolbar({ activeFilter, counts, onFilter, total, visible, sort, onSort }) {
  return (
    <div className="toolbar">
      <div className="segmented">
        {FILTERS.map(([key, label]) => (
          <button key={key} className={cx('seg', activeFilter === key && 'active')} onClick={() => onFilter(key)}>
            {label}<span className="badge-n">{counts[key]}</span>
          </button>
        ))}
      </div>
      <div className="toolbar-spacer"></div>
      <span className="toolbar-meta">{visible} of {total}</span>
      <select className="sort-select" value={sort} onChange={(e) => onSort(e.target.value)}>
        <option value="priority">Sort: Priority</option>
        <option value="name">Sort: Name</option>
        <option value="changes">Sort: Most changes</option>
      </select>
    </div>
  );
}

/* ── Status pill ─────────────────────────────────────────── */
function StatusPill({ wt, runtime }) {
  const L = window.LDEV;
  if (runtime === 'starting') return <span className="pill p-starting"><span className="pdot"></span>Starting</span>;
  if (runtime === 'stopping') return <span className="pill p-starting"><span className="pdot"></span>Stopping</span>;
  if (!wt.env) return <span className="pill p-noenv"><span className="pdot"></span>No env</span>;
  if (L.isRunning(wt)) return <span className="pill p-running"><span className="pdot"></span>Running</span>;
  return <span className="pill p-stopped"><span className="pdot"></span>Stopped</span>;
}

/* ── Worktree card ───────────────────────────────────────── */
function WorktreeCard({ wt, runtime, selected, onSelect, onStart, onStop, onLogs, onCopy, copied }) {
  const L = window.LDEV;
  const portCopied = copied === wt.env?.portalUrl;
  const pathCopied = copied === wt.path;
  const skey = L.statusKey(wt);
  const running = runtime === 'running' || (runtime == null && L.isRunning(wt));
  const busy = runtime === 'starting' || runtime === 'stopping';
  const ab = wt.aheadBehind || {};
  const reach = wt.env?.portalReachable;
  const reachCls = !wt.env ? 'r-idle' : running ? (reach === false ? 'r-down' : 'r-up') : 'r-idle';
  const svcUp = (wt.env?.services || []).filter((s) => L.svcTone(s) === 'green').length;
  const svcTotal = (wt.env?.services || []).length;
  const svcBad = L.failedServices(wt).length;

  return (
    <article className={cx('wt', `s-${running ? (svcBad || reach === false ? 'error' : 'running') : skey}`,
      selected && 'is-selected', busy && 'is-busy')}
      onClick={() => onSelect(wt.name)}>
      <div className="wt-head">
        <div className="wt-id">
          <div className="wt-name">
            <h3 title={wt.name}>{wt.name}</h3>
            {wt.isMain && <span className="tag-main">main</span>}
          </div>
          <div className="wt-branch" title={wt.branch}>
            <I.Branch size={12} />{wt.branch}
          </div>
        </div>
        <StatusPill wt={wt} runtime={busy ? runtime : null} />
      </div>

      <div className="wt-stats">
        <div className="stat">
          <span className="stat-k">Changes</span>
          <span className={cx('stat-v', !wt.changedFiles && 'muted')}>
            {wt.changedFiles || '0'}{wt.changedFiles ? <small>files</small> : <small>clean</small>}
          </span>
        </div>
        <div className="stat">
          <span className="stat-k">Sync</span>
          <span className={cx('stat-v', !(ab.ahead || ab.behind) && 'muted')}>
            {ab.ahead ? <span className="up">↑{ab.ahead}</span> : null}
            {ab.behind ? <span className="down">↓{ab.behind}</span> : null}
            {!ab.ahead && !ab.behind ? 'even' : null}
          </span>
        </div>
        <div className="stat">
          <span className="stat-k">Services</span>
          <span className={cx('stat-v', !running && 'muted')}>
            {running ? <span className={svcBad ? '' : 'up'} style={svcBad ? { color: 'var(--amber)' } : null}>{svcUp}/{svcTotal}</span> : '—'}
          </span>
        </div>
      </div>

      {wt.env?.portalUrl ? (
        <div className="wt-port" onClick={(e) => e.stopPropagation()}>
          <span className={cx('rdot', reachCls)}></span>
          <a href={running && reach !== false ? wt.env.portalUrl : undefined}
            target="_blank" rel="noreferrer"
            style={!running || reach === false ? { pointerEvents: 'none', color: 'var(--text-3)' } : null}>
            {wt.env.portalUrl.replace('http://', '')}
          </a>
          <button className={cx('copy', portCopied && 'done')} title="Copy URL"
            onClick={() => onCopy(wt.env.portalUrl)}>
            {portCopied ? <I.Check size={12} /> : <I.Copy size={12} />}
          </button>
        </div>
      ) : (
        <div className="wt-port" onClick={(e) => e.stopPropagation()}>
          <span className="rdot r-idle"></span>
          <span style={{ color: 'var(--text-3)', flex: 1 }}>No local runtime</span>
        </div>
      )}

      <button className={cx('wt-path', pathCopied && 'copied')} title={`Copy path · ${wt.path}`}
        onClick={(e) => { e.stopPropagation(); onCopy(wt.path); }}>
        <I.Folder size={13} />
        <span className="wt-path-text" dir="rtl">{'\u200e' + wt.path}</span>
        {pathCopied ? <I.Check size={13} /> : <I.Copy size={13} />}
      </button>

      <div className="wt-actions" onClick={(e) => e.stopPropagation()}>
        {running ? (
          <button className="act a-stop" disabled={busy} onClick={() => onStop(wt.name)}>
            <I.Stop size={13} />Stop
          </button>
        ) : (
          <button className="act a-start" disabled={busy} onClick={() => onStart(wt.name)}>
            <I.Play size={13} />{busy ? 'Starting…' : 'Start'}
          </button>
        )}
        {wt.env && <button className="act" onClick={() => onLogs(wt.name)}><I.Terminal size={13} />Logs</button>}
        <button className="act a-icon" title="Details" onClick={() => onSelect(wt.name)}><I.More size={14} /></button>
      </div>
    </article>
  );
}

Object.assign(window, { Header, Overview, Toolbar, WorktreeCard, StatusPill, cx, FILTERS });
