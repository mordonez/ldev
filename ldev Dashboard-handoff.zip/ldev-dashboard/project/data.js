/* ldev dashboard — realistic worktree dataset + helpers (global: window.LDEV) */
(function () {
  const BASE = 'C\\\\:\\\\Users\\\\mordonez\\\\Development\\\\GitHub\\\\labweb';
  const wtPath = (slug) =>
    'C:\\Users\\mordonez\\Development\\GitHub\\labweb\\.worktrees\\' + slug;

  // helper to build a changed-file list
  const F = (s, path) => ({ s, path });

  const liferayServices = (state) => {
    const up = state === 'running';
    return [
      { name: 'liferay', state: up ? 'running' : 'exited', health: up ? 'healthy' : null },
      { name: 'database', state: up ? 'running' : 'exited', health: up ? 'healthy' : null },
      { name: 'search', state: up ? 'running' : 'exited', health: up ? 'healthy' : null },
    ];
  };

  const worktrees = [
    {
      name: 'labweb',
      slug: 'main',
      isMain: true,
      branch: 'feat/ldev',
      path: 'C:\\Users\\mordonez\\Development\\GitHub\\labweb',
      env: { liferay: { state: 'running' }, portalUrl: 'http://127.0.0.1:8080', portalReachable: true,
        services: liferayServices('running') },
      changedFiles: 0,
      changedPaths: [],
      aheadBehind: { ahead: 0, behind: 0, base: 'origin/feat/ldev' },
      commits: [
        { hash: '15424e62', subject: 'feat: update vendor skills bundle', date: '2026-05-12' },
        { hash: 'a01c7733', subject: 'chore: bump dashboard deps', date: '2026-05-11' },
        { hash: 'd9921ab4', subject: 'docs: dashboard workflow page', date: '2026-05-10' },
      ],
    },
    {
      name: 'improveperformance',
      slug: 'improveperformance',
      branch: 'fix/improveperformance',
      path: wtPath('improveperformance'),
      env: { liferay: { state: 'running' }, portalUrl: 'http://127.0.0.1:8330', portalReachable: true,
        services: liferayServices('running') },
      changedFiles: 23,
      changedPaths: [
        F('M', '.gitignore'), F('A', 'docker/.env.example'), F('M', 'docker/README.md'),
        F('M', 'docker/docker-compose.yml'), F('A', 'docker/make.ps1'),
        F('A', 'docker/scripts/adapt-local-db.sql'), F('A', 'docker/scripts/download-db.sh'),
        F('A', 'docker/scripts/import-db.sh'),
        F('M', 'liferay/configs/local/portal-ext.properties'),
        F('M', 'liferay/modules/perf-cache/src/main/java/PerfCacheConfig.java'),
        F('M', 'liferay/modules/perf-cache/bnd.bnd'),
        F('D', 'liferay/modules/legacy-indexer/legacy.cfg'),
        F('M', 'liferay/themes/labweb-theme/package.json'),
      ],
      aheadBehind: { ahead: 126, behind: 46, base: 'origin/feat/ldev' },
      commits: [
        { hash: '089acdd4', subject: 'perf: reduce el cost in product list ADT', date: '2026-05-26' },
        { hash: 'c41be902', subject: 'perf: cache fragment collection lookups', date: '2026-05-25' },
        { hash: '7be1102a', subject: 'refactor: drop legacy indexer module', date: '2026-05-24' },
      ],
    },
    {
      name: 'fix-oauth-token',
      slug: 'fix-oauth-token',
      branch: 'fix/oauth-token-refresh',
      path: wtPath('fix-oauth-token'),
      env: { liferay: { state: 'running' }, portalUrl: 'http://127.0.0.1:8210', portalReachable: true,
        services: [
          { name: 'liferay', state: 'running', health: 'healthy' },
          { name: 'database', state: 'running', health: 'healthy' },
          { name: 'search', state: 'running', health: 'unhealthy' },
        ] },
      changedFiles: 2,
      changedPaths: [
        F('M', 'liferay/modules/oauth-installer/src/main/java/OAuthInstaller.java'),
        F('M', 'docker/.env.example'),
      ],
      aheadBehind: { ahead: 4, behind: 0, base: 'origin/feat/ldev' },
      commits: [
        { hash: 'b1f0e7c2', subject: 'fix: refresh oauth token before expiry', date: '2026-05-28' },
        { hash: '9a73d410', subject: 'test: add token refresh integration test', date: '2026-05-27' },
      ],
    },
    {
      name: 'fragment-export',
      slug: 'fragment-export',
      branch: 'feat/resource-export',
      path: wtPath('fragment-export'),
      env: { liferay: { state: 'running' }, portalUrl: 'http://127.0.0.1:8410', portalReachable: true,
        services: liferayServices('running') },
      changedFiles: 1,
      changedPaths: [F('M', 'src/features/liferay/resource-export.ts')],
      aheadBehind: { ahead: 8, behind: 0, base: 'origin/feat/ldev' },
      commits: [
        { hash: 'e22a9f81', subject: 'feat: export fragment collections to files', date: '2026-05-29' },
      ],
    },
    {
      name: 'e2e-ldev-webserver',
      slug: 'e2e-ldev-webserver',
      branch: 'fix/e2e-ldev-webserver',
      path: wtPath('e2e-ldev-webserver'),
      env: { liferay: { state: 'exited' }, portalUrl: 'http://127.0.0.1:8140', portalReachable: false,
        services: liferayServices('exited') },
      changedFiles: 3,
      changedPaths: [
        F('M', 'docker/docker-compose.webserver.yml'),
        F('A', 'docker/local-nginx/nginx.conf'),
        F('M', 'docker/scripts/start-webserver.sh'),
      ],
      aheadBehind: { ahead: 3, behind: 0, base: 'origin/feat/ldev' },
      commits: [
        { hash: '5f2c8d10', subject: 'fix: webserver health check timeout', date: '2026-05-23' },
      ],
    },
    {
      name: 'improveperformance-2',
      slug: 'improveperformance-2',
      branch: 'fix/improveperformance',
      path: wtPath('improveperformance-2'),
      env: { liferay: { state: 'exited' }, portalUrl: 'http://127.0.0.1:8504', portalReachable: false,
        services: liferayServices('exited') },
      changedFiles: 24,
      changedPaths: [
        F('M', 'liferay/configs/dockerenv/osgi/configs/SyncConfiguration.config'),
        F('M', 'liferay/configs/local/osgi/configs/SyncConfiguration.config'),
        F('M', 'liferay/modules/ub-enseyaments-web/configs/SyncConfiguration.config'),
        F('M', 'liferay/modules/ub-fitxes-utils/api/UbFitxesConstants.java'),
        F('M', 'liferay/modules/ub-fitxes-utils/service/UbFitxesIndexerPostProcessor.java'),
        F('M', 'liferay/modules/ub-indexer-post-processor/SearchResultSummaryIndexer.java'),
      ],
      aheadBehind: { ahead: 41, behind: 12, base: 'origin/feat/ldev' },
      commits: [
        { hash: '2db9aa05', subject: 'perf: batch indexer post-processing', date: '2026-05-22' },
      ],
    },
    {
      name: 'migrate-structures',
      slug: 'migrate-structures',
      branch: 'feat/structure-migration',
      path: wtPath('migrate-structures'),
      env: { liferay: { state: 'exited' }, portalUrl: 'http://127.0.0.1:8260', portalReachable: false,
        services: liferayServices('exited') },
      changedFiles: 7,
      changedPaths: [
        F('A', 'src/features/liferay/migration-pipeline.ts'),
        F('A', 'src/features/liferay/migration-init.ts'),
        F('M', 'src/commands/resource.ts'),
        F('A', 'tests/migration-pipeline.test.ts'),
      ],
      aheadBehind: { ahead: 19, behind: 5, base: 'origin/feat/ldev' },
      commits: [
        { hash: 'aa01ffe3', subject: 'feat: migration pipeline for journal structures', date: '2026-05-21' },
      ],
    },
    {
      name: 'db-sync-lcp',
      slug: 'db-sync-lcp',
      branch: 'chore/db-sync',
      path: wtPath('db-sync-lcp'),
      env: { liferay: { state: 'running' }, portalUrl: 'http://127.0.0.1:8190', portalReachable: true,
        services: liferayServices('running') },
      changedFiles: 2,
      changedPaths: [
        F('M', 'src/features/db/db-sync.ts'),
        F('M', 'docker/scripts/import-db.sh'),
      ],
      aheadBehind: { ahead: 3, behind: 0, base: 'origin/feat/ldev' },
      commits: [
        { hash: 'cc77a120', subject: 'chore: sync db from lcp backup', date: '2026-05-20' },
      ],
    },
    {
      name: 'headless-inventory',
      slug: 'headless-inventory',
      branch: 'feat/portal-inventory',
      path: wtPath('headless-inventory'),
      env: { liferay: { state: 'exited' }, portalUrl: 'http://127.0.0.1:8320', portalReachable: false,
        services: liferayServices('exited') },
      changedFiles: 5,
      changedPaths: [
        F('M', 'src/features/liferay/portal-inventory.ts'),
        F('A', 'src/features/liferay/inventory-sites.ts'),
        F('A', 'src/features/liferay/inventory-pages.ts'),
      ],
      aheadBehind: { ahead: 6, behind: 12, base: 'origin/feat/ldev' },
      commits: [
        { hash: 'fa0091bd', subject: 'feat: consolidate portal inventory calls', date: '2026-05-18' },
      ],
    },
    {
      name: 'hotfix-login',
      slug: 'hotfix-login',
      branch: 'hotfix/login-redirect',
      path: wtPath('hotfix-login'),
      env: { liferay: { state: 'exited' }, portalUrl: 'http://127.0.0.1:8150', portalReachable: false,
        services: liferayServices('exited') },
      changedFiles: 0,
      changedPaths: [],
      aheadBehind: { ahead: 1, behind: 8, base: 'origin/feat/ldev' },
      commits: [
        { hash: '730bb918', subject: 'hotfix: correct post-login redirect loop', date: '2026-05-15' },
      ],
    },
    {
      name: 'upgrade-node24',
      slug: 'upgrade-node24',
      branch: 'chore/upgrade-node-24',
      path: wtPath('upgrade-node24'),
      env: null,
      changedFiles: 0,
      changedPaths: [],
      aheadBehind: { ahead: 0, behind: 0, base: 'origin/feat/ldev' },
      commits: [
        { hash: '4c5b2e90', subject: 'chore: bump engines to node 24', date: '2026-05-09' },
      ],
    },
    {
      name: 'docs-dashboard',
      slug: 'docs-dashboard',
      branch: 'docs/dashboard-workflow',
      path: wtPath('docs-dashboard'),
      env: null,
      changedFiles: 4,
      changedPaths: [
        F('M', 'docs/workflows/dashboard.md'),
        F('A', 'docs/public/dashboard-overview.png'),
        F('M', 'README.md'),
        F('M', 'docs/.vitepress/config.ts'),
      ],
      aheadBehind: { ahead: 2, behind: 0, base: 'origin/feat/ldev' },
      commits: [
        { hash: '88ad0c41', subject: 'docs: write dashboard workflow guide', date: '2026-05-08' },
      ],
    },
  ];

  // ── derived state helpers ──
  const isRunning = (wt) => wt.env?.liferay?.state === 'running';
  const isStopped = (wt) => wt.env && !isRunning(wt);
  const isDirty = (wt) => (wt.changedFiles || 0) > 0;
  const isBehind = (wt) => (wt.aheadBehind?.behind || 0) > 0;
  const svcTone = (s) =>
    s.state === 'running' && (s.health === 'healthy' || !s.health) ? 'green'
    : s.state === 'running' ? 'amber'
    : s.state === 'exited' || s.state === 'dead' ? 'red' : 'gray';
  const failedServices = (wt) => (wt.env?.services || []).filter((s) => isRunning(wt) && svcTone(s) === 'amber');

  function attentionReasons(wt) {
    const r = [];
    if (isDirty(wt)) r.push(`${wt.changedFiles} uncommitted change${wt.changedFiles > 1 ? 's' : ''}`);
    if (isBehind(wt)) r.push(`${wt.aheadBehind.behind} commits behind ${wt.aheadBehind.base}`);
    if (isRunning(wt)) {
      if (wt.env?.portalReachable === false) r.push('portal not reachable');
      for (const s of failedServices(wt)) r.push(`service ${s.name} unhealthy`);
    }
    return r;
  }
  const needsAttention = (wt) => attentionReasons(wt).length > 0;

  function statusKey(wt) {
    if (isRunning(wt)) {
      if (wt.env?.portalReachable === false || failedServices(wt).length) return 'error';
      return 'running';
    }
    if (needsAttention(wt)) return 'attention';
    if (wt.isMain) return 'main';
    return 'idle';
  }

  function priority(wt) {
    if (statusKey(wt) === 'error') return 0;
    if (isRunning(wt)) return 1;
    if (needsAttention(wt)) return 2;
    if (wt.isMain) return 3;
    return 4;
  }

  window.LDEV = {
    cwd: 'C:\\Users\\mordonez\\Development\\GitHub\\labweb',
    worktrees,
    isRunning, isStopped, isDirty, isBehind, svcTone, failedServices,
    attentionReasons, needsAttention, statusKey, priority,
  };
})();
