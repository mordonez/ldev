/* ldev dashboard — slide-over detail, logs modal, activity dock, new-worktree modal */
const { useState: useStateD, useRef: useRefD, useEffect: useEffectD } = React;
const useState = useStateD, useRef = useRefD, useEffect = useEffectD;

/* ── Slide-over detail sheet ─────────────────────────────── */
function DetailSheet({ wt, runtime, onClose, onStart, onStop, onLogs, onAction, onCopy, copied }) {
  const L = window.LDEV;
  const running = runtime === 'running' || (runtime == null && L.isRunning(wt));
  const busy = runtime === 'starting' || runtime === 'stopping';
  const ab = wt.aheadBehind || {};
  const reasons = L.attentionReasons(wt);
  const services = wt.env?.services || [];

  useEffect(() => {
    const esc = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', esc);
    return () => window.removeEventListener('keydown', esc);
  }, []);

  const ftag = { M: 'm', A: 'a', D: 'd', R: 'r' };
  const ftagLabel = { M: 'M', A: 'A', D: 'D', R: 'R' };

  return (
    <React.Fragment>
      <div className="scrim" onClick={onClose}></div>
      <aside className="sheet" role="dialog">
        <div className="sheet-head">
          <div className="sheet-top">
            <div className="sheet-title">
              <h2 title={wt.name}>{wt.name}</h2>
              {wt.isMain && <span className="tag-main">main</span>}
              <StatusPill wt={wt} runtime={busy ? runtime : null} />
            </div>
            <button className="sheet-close" onClick={onClose}><I.Close size={16} /></button>
          </div>
          <div className="sheet-branch">
            <I.Branch size={13} />{wt.branch}
            <span style={{ color: 'var(--text-3)' }}>·</span>
            {ab.ahead ? <span style={{ color: 'var(--green)' }}>↑{ab.ahead}</span> : null}
            {ab.behind ? <span style={{ color: 'var(--amber)' }}>↓{ab.behind}</span> : null}
            <span style={{ color: 'var(--text-3)' }}>{ab.base}</span>
          </div>
          <div className="sheet-actions">
            {running ? (
              <button className="act a-stop" style={{ flex: '0 0 auto', padding: '8px 16px' }} disabled={busy} onClick={() => onStop(wt.name)}>
                <I.Stop size={13} />Stop env
              </button>
            ) : (
              <button className="act a-start" style={{ flex: '0 0 auto', padding: '8px 16px' }} disabled={busy} onClick={() => onStart(wt.name)}>
                <I.Play size={13} />{busy ? 'Starting…' : 'Start env'}
              </button>
            )}
            {wt.env && <button className="btn" onClick={() => onLogs(wt.name)}><I.Terminal size={14} />Logs</button>}
            <button className="btn" onClick={() => onAction('db', wt.name)}><I.Database size={14} />DB sync</button>
          </div>
        </div>

        <div className="sheet-body">
          {reasons.length ? (
            <div className="det-cell full" style={{ borderColor: 'var(--amber-bd)', background: 'var(--amber-bg)' }}>
              <div className="det-k" style={{ color: 'var(--amber)', display: 'flex', alignItems: 'center', gap: 6 }}>
                <I.Alert size={13} />Needs attention
              </div>
              <div style={{ fontSize: 12.5, color: 'var(--text)', lineHeight: 1.6 }}>
                {reasons.join(' · ')}
              </div>
            </div>
          ) : (
            <div className="det-cell full" style={{ borderColor: 'var(--green-bd)', background: 'var(--green-bg)' }}>
              <div className="det-k" style={{ color: 'var(--green)', display: 'flex', alignItems: 'center', gap: 6 }}>
                <I.Check size={13} />All clear
              </div>
              <div style={{ fontSize: 12.5, color: 'var(--text)' }}>Clean tree, in sync, runtime healthy.</div>
            </div>
          )}

          <div className="det-grid">
            <div className="det-cell">
              <span className="det-k">Portal</span>
              <span className="det-v">
                <span className={cx('rdot', !wt.env ? 'r-idle' : running ? (wt.env.portalReachable === false ? 'r-down' : 'r-up') : 'r-idle')}></span>
                {wt.env?.portalUrl ? (
                  <a href={running ? wt.env.portalUrl : undefined} target="_blank" rel="noreferrer"
                    style={{ color: running ? 'var(--accent)' : 'var(--text-3)', textDecoration: 'none' }}>
                    {wt.env.portalUrl.replace('http://', '')}
                  </a>
                ) : <span style={{ color: 'var(--text-3)' }}>none</span>}
              </span>
            </div>
            <div className="det-cell">
              <span className="det-k">Changes</span>
              <span className="det-v" style={{ color: wt.changedFiles ? 'var(--amber)' : 'var(--text-3)' }}>
                {wt.changedFiles ? `${wt.changedFiles} files` : 'clean'}
              </span>
            </div>
            <div className="det-cell full">
              <span className="det-k">Path</span>
              <span className="det-v" style={{ fontSize: 12 }}>
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{wt.path}</span>
                <button className={cx('copy', copied === wt.path && 'done')} style={{ marginLeft: 'auto' }}
                  onClick={() => onCopy(wt.path)}>
                  {copied === wt.path ? <I.Check size={12} /> : <I.Copy size={12} />}
                </button>
              </span>
            </div>
          </div>

          {wt.changedPaths?.length ? (
            <div className="sec">
              <div className="sec-head">
                <div className="sec-title"><I.File size={14} />Changed files
                  <span className="cnt warn">{wt.changedFiles}</span></div>
              </div>
              <div className="files">
                {wt.changedPaths.map((f, i) => (
                  <div className="file" key={i}>
                    <span className={cx('ftag', ftag[f.s])}>{ftagLabel[f.s]}</span>
                    <span className="fpath" title={f.path}>{'\u200e' + f.path}</span>
                  </div>
                ))}
                {wt.changedFiles > wt.changedPaths.length ? (
                  <div className="file" style={{ color: 'var(--text-3)', justifyContent: 'center' }}>
                    +{wt.changedFiles - wt.changedPaths.length} more files
                  </div>
                ) : null}
              </div>
            </div>
          ) : null}

          {wt.env ? (
            <div className="sec">
              <div className="sec-head">
                <div className="sec-title"><I.Box size={14} />Services
                  <span className={cx('cnt', L.failedServices(wt).length && 'warn')}>
                    {running ? `${services.filter((s) => L.svcTone(s) === 'green').length}/${services.length} up` : 'stopped'}
                  </span>
                </div>
              </div>
              <div className="svc-list">
                {services.map((s, i) => {
                  const tone = running ? L.svcTone(s) : 'gray';
                  const label = running ? (s.health || s.state) : 'exited';
                  const cls = tone === 'green' ? 'ok' : tone === 'amber' ? 'warn' : tone === 'red' ? 'down' : '';
                  return (
                    <div className="svc" key={i}>
                      <span className={cx('sdot', `dot-${tone === 'gray' ? 'gray' : tone}`)}></span>
                      <span className="svc-name">{s.name}</span>
                      <span className={cx('svc-state', cls)}>{label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : null}

          <div className="sec">
            <div className="sec-head">
              <div className="sec-title"><I.GitCommit size={14} />Recent commits
                <span className="cnt">{wt.commits.length}</span></div>
            </div>
            <div className="commits">
              {wt.commits.map((c, i) => (
                <div className="commit" key={i}>
                  <span className="ch">{c.hash}</span>
                  <span className="cs" title={c.subject}>{c.subject}</span>
                  <span className="cd">{c.date}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="sec">
            <div className="sec-title" style={{ marginBottom: 2 }}>Operations</div>
            <div className="adv">
              <button className="btn" onClick={() => onAction('resource', wt.name)}><I.Package size={14} />Resource export</button>
              <button className="btn" onClick={() => onAction('oauth', wt.name)}><I.Key size={14} />OAuth install</button>
              <button className="btn" onClick={() => onAction('deploy', wt.name)}><I.Chart size={14} />Deploy status</button>
              <button className="btn" onClick={() => onAction('recreate', wt.name)}><I.Rotate size={14} />Recreate</button>
              {!wt.isMain && (
                <button className="btn" style={{ color: 'var(--red)', gridColumn: '1/-1' }}
                  onClick={() => onAction('delete', wt.name)}><I.Trash size={14} />Delete worktree</button>
              )}
            </div>
          </div>
        </div>
      </aside>
    </React.Fragment>
  );
}

/* ── Logs modal ──────────────────────────────────────────── */
const LOG_SAMPLE = [
  ['07:42:01', 'info', 'Starting docker compose stack (3 services)'],
  ['07:42:02', 'info', 'Network labweb_default created'],
  ['07:42:03', 'ok', 'Container labweb-database-1  Healthy'],
  ['07:42:09', 'info', 'Liferay starting — modules framework initializing'],
  ['07:42:14', 'warn', 'Reindex recommended: search volume changed since last boot'],
  ['07:42:22', 'info', 'Deploying 6 OSGi modules from osgi/modules'],
  ['07:42:31', 'ok', 'Bundle es.ricoh.ub.fitxes.utils [482] started'],
  ['07:42:38', 'ok', 'Server startup in 36.4s — portal available'],
  ['07:42:39', 'info', 'GET / 200 (127.0.0.1:8330)'],
  ['07:43:02', 'err', 'NoSuchLayoutException: friendlyURL /old-home not found'],
  ['07:43:05', 'info', 'GET /web/guest 200'],
];
function LogsModal({ wt, onClose }) {
  const bodyRef = useRef(null);
  useEffect(() => {
    const esc = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', esc);
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
    return () => window.removeEventListener('keydown', esc);
  }, []);
  return (
    <div className="modal-scrim" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h3><I.Terminal size={16} />{wt.name}<span className="sub">docker compose logs · follow</span></h3>
          <button className="sheet-close" onClick={onClose}><I.Close size={16} /></button>
        </div>
        <div className="modal-body" ref={bodyRef}>
          {LOG_SAMPLE.map(([t, v, m], i) => (
            <div className="logline" key={i}>
              <span className="lt">{t}</span>
              <span className={cx('lv', v)}>{v.toUpperCase()}</span>
              <span className="lm">{m}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── Activity dock ───────────────────────────────────────── */
function ActivityDock({ tasks, collapsed, onToggle }) {
  const active = tasks.filter((t) => t.status === 'running').length;
  return (
    <div className="dock">
      <div className="dock-inner">
        <div className="dock-head" onClick={onToggle}>
          <span className="dt">
            {active ? <span className="dock-spin"></span> : <I.Activity size={13} />}
            Activity
          </span>
          <span className="dmeta">{active ? `${active} running` : 'No active tasks'}</span>
          <div style={{ flex: 1 }}></div>
          <I.Chevron size={16} style={{ color: 'var(--text-3)', transform: collapsed ? 'rotate(0deg)' : 'rotate(180deg)', transition: '.2s' }} />
        </div>
        {!collapsed && (
          <div className="dock-body">
            {tasks.length === 0 ? (
              <div className="dock-empty">Operations you run will stream here.</div>
            ) : (
              tasks.map((t) => (
                <div className={cx('task', t.status)} key={t.id}>
                  <div className="task-top">
                    <span className="task-ic">
                      {t.status === 'running' ? <I.Rotate size={14} /> : t.status === 'failed' ? <I.Alert size={14} /> : <I.Check size={14} />}
                    </span>
                    <div className="task-main">
                      <div className="task-title">{t.title}</div>
                      <div className="task-sub">{t.sub}</div>
                    </div>
                    <span className={cx('task-st', t.status)}>{t.status}</span>
                  </div>
                  {t.status === 'running' && (
                    <div className="task-bar"><i style={{ width: `${t.progress}%` }}></i></div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/* ── New worktree modal ──────────────────────────────────── */
function NewWorktreeModal({ onClose, onCreate }) {
  const [name, setName] = useState('');
  const [branch, setBranch] = useState('');
  const [withEnv, setWithEnv] = useState(true);
  const [startAfter, setStartAfter] = useState(false);
  useEffect(() => {
    const esc = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', esc);
    return () => window.removeEventListener('keydown', esc);
  }, []);
  return (
    <div className="modal-scrim" onClick={onClose}>
      <div className="modal" style={{ height: 'auto', maxWidth: 480 }} onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h3><I.Plus size={16} />New worktree</h3>
          <button className="sheet-close" onClick={onClose}><I.Close size={16} /></button>
        </div>
        <div className="form">
          <div className="field">
            <label>Worktree name</label>
            <input value={name} placeholder="e.g. fix-checkout" onInput={(e) => setName(e.target.value)} autoFocus />
            <span className="hint">Created under .worktrees/</span>
          </div>
          <div className="field">
            <label>Branch</label>
            <input value={branch} placeholder="feat/checkout" onInput={(e) => setBranch(e.target.value)} />
          </div>
          <label className="check"><input type="checkbox" checked={withEnv} onChange={(e) => setWithEnv(e.target.checked)} />Provision isolated env (Postgres, Liferay, OSGi)</label>
          <label className="check"><input type="checkbox" checked={startAfter} onChange={(e) => setStartAfter(e.target.checked)} />Start runtime right after creating</label>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 4 }}>
            <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn btn-primary" disabled={!name} onClick={() => onCreate({ name, branch, withEnv, startAfter })}>Create worktree</button>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { DetailSheet, LogsModal, ActivityDock, NewWorktreeModal });
